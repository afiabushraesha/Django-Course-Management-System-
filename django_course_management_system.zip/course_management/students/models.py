from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    student_id = models.CharField(max_length=20, unique=True)
    phone_number = models.CharField(max_length=15, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.student_id}"
    
    def get_enrollment_count(self):
        return self.enrollment_set.count()
    
    def can_enroll(self):
        return self.get_enrollment_count() < 5

class Course(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=10, unique=True)
    description = models.TextField()
    instructor = models.CharField(max_length=100)
    credits = models.IntegerField()
    max_students = models.IntegerField(default=50)
    
    def __str__(self):
        return f"{self.code} - {self.name}"
    
    def get_enrolled_count(self):
        return self.enrollment_set.count()
    
    def is_full(self):
        return self.get_enrolled_count() >= self.max_students

class Enrollment(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    enrolled_date = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('student', 'course')
    
    def __str__(self):
        return f"{self.student.user.username} - {self.course.code}"
    
    def clean(self):
        if self.student.get_enrollment_count() >= 5:
            raise ValidationError("Student cannot enroll in more than 5 courses.")
        if self.course.is_full():
            raise ValidationError("Course is full.")

class FileUpload(models.Model):
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    file = models.FileField(upload_to='uploads/')
    description = models.CharField(max_length=255, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.file.name} - {self.course.code}"
    
    def get_file_name(self):
        return self.file.name.split('/')[-1]