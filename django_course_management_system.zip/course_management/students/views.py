from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse, Http404
from django.core.exceptions import ValidationError
from .models import Student, Course, Enrollment, FileUpload
from .forms import StudentRegistrationForm, FileUploadForm

def register(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful!')
            return redirect('course_list')
    else:
        form = StudentRegistrationForm()
    return render(request, 'registration/register.html', {'form': form})

@login_required
def course_list(request):
    courses = Course.objects.all()
    student = get_object_or_404(Student, user=request.user)
    enrolled_courses = student.enrollment_set.values_list('course_id', flat=True)
    
    context = {
        'courses': courses,
        'enrolled_courses': enrolled_courses,
        'student': student,
    }
    return render(request, 'students/course_list.html', context)

@login_required
def enroll_course(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    student = get_object_or_404(Student, user=request.user)
    
    if not student.can_enroll():
        messages.error(request, 'You cannot enroll in more than 5 courses.')
        return redirect('course_list')
    
    if course.is_full():
        messages.error(request, 'This course is full.')
        return redirect('course_list')
    
    enrollment, created = Enrollment.objects.get_or_create(
        student=student,
        course=course
    )
    
    if created:
        messages.success(request, f'You have successfully enrolled in {course.name}!')
    else:
        messages.info(request, f'You are already enrolled in {course.name}.')
    
    return redirect('course_list')

@login_required
def enrollment_list(request):
    student = get_object_or_404(Student, user=request.user)
    enrollments = student.enrollment_set.all()
    return render(request, 'students/enrollment_list.html', {'enrollments': enrollments})

@login_required
def file_upload(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    student = get_object_or_404(Student, user=request.user)
    
    # Check if student is enrolled in the course
    if not Enrollment.objects.filter(student=student, course=course).exists():
        messages.error(request, 'You must be enrolled in this course to upload files.')
        return redirect('course_list')
    
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            file_upload = form.save(commit=False)
            file_upload.uploaded_by = request.user
            file_upload.course = course
            file_upload.save()
            messages.success(request, 'File uploaded successfully!')
            return redirect('file_list', course_id=course.id)
    else:
        form = FileUploadForm()
    
    return render(request, 'students/file_upload.html', {'form': form, 'course': course})

@login_required
def file_list(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    student = get_object_or_404(Student, user=request.user)
    
    # Check if student is enrolled in the course
    if not Enrollment.objects.filter(student=student, course=course).exists():
        messages.error(request, 'You must be enrolled in this course to view files.')
        return redirect('course_list')
    
    files = FileUpload.objects.filter(course=course)
    return render(request, 'students/file_list.html', {'files': files, 'course': course})

@login_required
def download_file(request, file_id):
    file_upload = get_object_or_404(FileUpload, id=file_id)
    student = get_object_or_404(Student, user=request.user)
    
    # Check if student is enrolled in the course
    if not Enrollment.objects.filter(student=student, course=file_upload.course).exists():
        raise Http404("File not found")
    
    response = HttpResponse(file_upload.file.read(), content_type='application/octet-stream')
    response['Content-Disposition'] = f'attachment; filename="{file_upload.get_file_name()}"'
    return response

@login_required
def delete_file(request, file_id):
    file_upload = get_object_or_404(FileUpload, id=file_id)
    
    # Only the uploader or admin can delete files
    if file_upload.uploaded_by != request.user and not request.user.is_staff:
        messages.error(request, 'You can only delete files you uploaded.')
        return redirect('file_list', course_id=file_upload.course.id)
    
    course_id = file_upload.course.id
    file_upload.delete()
    messages.success(request, 'File deleted successfully!')
    return redirect('file_list', course_id=course_id)