# Run this in Django shell: python manage.py shell
from students.models import Course

# Create sample courses
courses_data = [
    {
        'name': 'Introduction to Computer Science',
        'code': 'CS101',
        'description': 'Fundamentals of computer science including programming basics, algorithms, and data structures.',
        'instructor': 'Dr. Smith',
        'credits': 3,
        'max_students': 30
    },
    {
        'name': 'Data Structures and Algorithms',
        'code': 'CS201',
        'description': 'Advanced data structures, algorithm design, and complexity analysis.',
        'instructor': 'Dr. Johnson',
        'credits': 4,
        'max_students': 25
    },
    {
        'name': 'Database Systems',
        'code': 'CS301',
        'description': 'Database design, SQL, normalization, and database management systems.',
        'instructor': 'Dr. Williams',
        'credits': 3,
        'max_students': 35
    },
    {
        'name': 'Web Development',
        'code': 'CS350',
        'description': 'Full-stack web development using modern frameworks and technologies.',
        'instructor': 'Dr. Brown',
        'credits': 4,
        'max_students': 20
    },
    {
        'name': 'Machine Learning',
        'code': 'CS450',
        'description': 'Introduction to machine learning algorithms and applications.',
        'instructor': 'Dr. Davis',
        'credits': 3,
        'max_students': 15
    }
]

for course_data in courses_data:
    Course.objects.get_or_create(**course_data)

print("Sample courses created successfully!")